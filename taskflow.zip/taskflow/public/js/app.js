(() => {
  const $ = (id) => document.getElementById(id);
  const STATUSES = ['todo', 'in-progress', 'done'];
  const LABELS = { todo: 'To do', 'in-progress': 'In progress', done: 'Done' };

  const state = {
    token: localStorage.getItem('tf_token'),
    user: null,
    tasks: [],
    socket: null,
    editingId: null,
    mode: 'login'
  };

  // ---------- helpers ----------
  const el = (tag, props = {}, children = []) => {
    const node = document.createElement(tag);
    Object.assign(node, props);
    children.forEach((c) => node.append(c));
    return node;
  };

  async function api(path, options = {}) {
    const res = await fetch('/api' + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}),
        ...(options.headers || {})
      }
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && state.token && !path.startsWith('/auth/')) logout();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  }

  // ---------- auth ----------
  function setMode(mode) {
    state.mode = mode;
    const register = mode === 'register';
    $('tabLogin').setAttribute('aria-selected', String(!register));
    $('tabRegister').setAttribute('aria-selected', String(register));
    $('nameField').hidden = !register;
    $('authSubmit').textContent = register ? 'Create account' : 'Log in';
    $('authPassword').autocomplete = register ? 'new-password' : 'current-password';
    $('authError').textContent = '';
  }
  $('tabLogin').addEventListener('click', () => setMode('login'));
  $('tabRegister').addEventListener('click', () => setMode('register'));

  $('authForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('authSubmit');
    const body = { email: $('authEmail').value.trim(), password: $('authPassword').value };
    if (state.mode === 'register') body.name = $('authName').value.trim();
    btn.disabled = true;
    $('authError').textContent = '';
    try {
      const data = await api('/auth/' + state.mode, { method: 'POST', body: JSON.stringify(body) });
      state.token = data.token;
      state.user = data.user;
      localStorage.setItem('tf_token', data.token);
      $('authForm').reset();
      await startApp();
    } catch (err) {
      $('authError').textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  function logout() {
    localStorage.removeItem('tf_token');
    state.token = null;
    state.user = null;
    state.tasks = [];
    if (state.socket) state.socket.disconnect();
    state.socket = null;
    $('appView').hidden = true;
    $('authView').hidden = false;
  }
  $('logoutBtn').addEventListener('click', logout);

  // ---------- real-time (Socket.IO) ----------
  function connectSocket() {
    if (state.socket) state.socket.disconnect();
    const live = $('liveStatus');
    const socket = io({ auth: { token: state.token } });
    state.socket = socket;

    socket.on('connect', () => { live.textContent = 'Live'; live.classList.add('on'); });
    socket.on('disconnect', () => { live.textContent = 'Offline'; live.classList.remove('on'); });
    socket.on('connect_error', () => { live.textContent = 'Offline'; live.classList.remove('on'); });

    // These handlers are safe to run twice (the tab that made the change also gets the event).
    socket.on('task:created', (task) => {
      if (!state.tasks.some((t) => t._id === task._id)) state.tasks.unshift(task);
      render();
    });
    socket.on('task:updated', (task) => {
      const i = state.tasks.findIndex((t) => t._id === task._id);
      if (i === -1) state.tasks.unshift(task); else state.tasks[i] = task;
      render();
    });
    socket.on('task:deleted', ({ _id }) => {
      state.tasks = state.tasks.filter((t) => t._id !== _id);
      render();
    });
  }

  // ---------- rendering ----------
  function formatDue(task) {
    if (!task.dueDate) return null;
    const due = new Date(task.dueDate);
    const text = 'Due ' + due.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
    const today = new Date(); today.setUTCHours(0, 0, 0, 0);
    const overdue = task.status !== 'done' && due < today;
    return { text: overdue ? text + ' (overdue)' : text, overdue };
  }

  function taskCard(task) {
    const meta = el('div', { className: 'meta' }, [el('span', { textContent: 'Priority: ' + task.priority })]);
    const due = formatDue(task);
    if (due) meta.append(el('span', { className: due.overdue ? 'overdue' : '', textContent: due.text }));

    const move = el('select', { ariaLabel: 'Move task to' });
    move.setAttribute('aria-label', 'Change status of ' + task.title);
    STATUSES.forEach((s) => {
      const opt = el('option', { value: s, textContent: LABELS[s] });
      opt.selected = s === task.status;
      move.append(opt);
    });
    move.addEventListener('change', () => updateTask(task._id, { status: move.value }));

    const edit = el('button', { type: 'button', textContent: 'Edit' });
    edit.addEventListener('click', () => openDialog(task));
    const del = el('button', { type: 'button', className: 'del', textContent: 'Delete' });
    del.addEventListener('click', () => removeTask(task));

    const li = el('li', { className: `task p-${task.priority}${task.status === 'done' ? ' is-done' : ''}` }, [
      el('h3', { textContent: task.title })
    ]);
    if (task.description) li.append(el('p', { textContent: task.description }));
    li.append(meta, el('div', { className: 'actions' }, [move, edit, del]));
    return li;
  }

  function render() {
    const q = $('search').value.trim().toLowerCase();
    const priority = $('priorityFilter').value;
    const visible = state.tasks.filter(
      (t) =>
        (!priority || t.priority === priority) &&
        (!q || t.title.toLowerCase().includes(q) || (t.description || '').toLowerCase().includes(q))
    );
    STATUSES.forEach((s) => {
      const items = visible.filter((t) => t.status === s);
      $('count-' + s).textContent = items.length;
      $('list-' + s).replaceChildren(
        ...(items.length ? items.map(taskCard) : [el('li', { className: 'empty', textContent: 'No tasks here.' })])
      );
    });
  }
  $('search').addEventListener('input', render);
  $('priorityFilter').addEventListener('change', render);

  // ---------- CRUD ----------
  async function updateTask(id, changes, rethrow = false) {
    try {
      const updated = await api('/tasks/' + id, { method: 'PUT', body: JSON.stringify(changes) });
      const i = state.tasks.findIndex((t) => t._id === id);
      if (i !== -1) state.tasks[i] = updated;
      render();
    } catch (err) {
      if (rethrow) throw err;
      alert(err.message);
      render();
    }
  }

  async function removeTask(task) {
    if (!confirm(`Delete "${task.title}"?`)) return;
    try {
      await api('/tasks/' + task._id, { method: 'DELETE' });
      state.tasks = state.tasks.filter((t) => t._id !== task._id);
      render();
    } catch (err) {
      alert(err.message);
    }
  }

  // ---------- task dialog ----------
  const dialog = $('taskDialog');

  function openDialog(task) {
    state.editingId = task ? task._id : null;
    $('dialogTitle').textContent = task ? 'Edit task' : 'New task';
    $('taskTitle').value = task ? task.title : '';
    $('taskDesc').value = task ? task.description || '' : '';
    $('taskPriority').value = task ? task.priority : 'medium';
    $('taskStatus').value = task ? task.status : 'todo';
    $('taskDue').value = task && task.dueDate ? task.dueDate.slice(0, 10) : '';
    $('taskError').textContent = '';
    dialog.showModal();
    $('taskTitle').focus();
  }
  $('newTaskBtn').addEventListener('click', () => openDialog(null));
  $('cancelBtn').addEventListener('click', () => dialog.close());

  $('taskForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = {
      title: $('taskTitle').value.trim(),
      description: $('taskDesc').value.trim(),
      priority: $('taskPriority').value,
      status: $('taskStatus').value,
      dueDate: $('taskDue').value || null
    };
    if (!body.title) {
      $('taskError').textContent = 'Enter a title for the task.';
      return;
    }
    $('saveBtn').disabled = true;
    try {
      if (state.editingId) {
        await updateTask(state.editingId, body, true);
      } else {
        const created = await api('/tasks', { method: 'POST', body: JSON.stringify(body) });
        if (!state.tasks.some((t) => t._id === created._id)) state.tasks.unshift(created);
        render();
      }
      dialog.close();
    } catch (err) {
      $('taskError').textContent = err.message;
    } finally {
      $('saveBtn').disabled = false;
    }
  });

  // ---------- start ----------
  async function startApp() {
    if (!state.user) state.user = (await api('/auth/me')).user;
    state.tasks = await api('/tasks');
    $('userName').textContent = state.user.name;
    $('authView').hidden = true;
    $('appView').hidden = false;
    render();
    connectSocket();
  }

  setMode('login');
  if (state.token) startApp().catch(logout);
})();
