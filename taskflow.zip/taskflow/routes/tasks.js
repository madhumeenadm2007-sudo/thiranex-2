const express = require('express');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

const router = express.Router();
router.use(auth); // every task route needs a logged-in user

const FIELDS = ['title', 'description', 'status', 'priority', 'dueDate'];

function pick(body = {}) {
  const data = {};
  FIELDS.forEach((f) => {
    if (body[f] !== undefined) data[f] = body[f];
  });
  if ('dueDate' in data && !data.dueDate) data.dueDate = null;
  return data;
}

function handleError(res, err) {
  if (err.name === 'ValidationError') return res.status(400).json({ error: Object.values(err.errors)[0].message });
  if (err.name === 'CastError') return res.status(400).json({ error: 'Invalid value or task id.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong.' });
}

// Real-time: tell every open session of this user.
const notify = (req, event, payload) => req.app.get('io').to(`user:${req.user.id}`).emit(event, payload);

// GET /api/tasks
router.get('/', async (req, res) => {
  try {
    res.json(await Task.find({ owner: req.user.id }).sort({ createdAt: -1 }));
  } catch (err) {
    handleError(res, err);
  }
});

// POST /api/tasks
router.post('/', async (req, res) => {
  try {
    const task = await Task.create({ ...pick(req.body), owner: req.user.id });
    notify(req, 'task:created', task);
    res.status(201).json(task);
  } catch (err) {
    handleError(res, err);
  }
});

// PUT /api/tasks/:id  (authorization: only the owner can change it)
router.put('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndUpdate({ _id: req.params.id, owner: req.user.id }, pick(req.body), {
      new: true,
      runValidators: true
    });
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    notify(req, 'task:updated', task);
    res.json(task);
  } catch (err) {
    handleError(res, err);
  }
});

// DELETE /api/tasks/:id
router.delete('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    notify(req, 'task:deleted', { _id: task._id });
    res.json({ deleted: true });
  } catch (err) {
    handleError(res, err);
  }
});

module.exports = router;
