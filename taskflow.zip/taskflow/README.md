# TaskFlow – Task Management Application

A full-stack task manager with user accounts, task CRUD and real-time updates.

**Stack:** HTML/CSS/JavaScript frontend · Node.js + Express API · MongoDB (Mongoose) · JWT authentication · Socket.IO (WebSockets)

## Features

- **Authentication & authorization:** register and log in with email and password. Passwords are hashed with bcrypt, sessions use JWT. Every task belongs to one user, and the API only lets the owner read, change or delete it.
- **CRUD:** create, view, edit, delete tasks with title, description, priority, status and due date.
- **Board:** tasks sit in To do / In progress / Done columns. Change status with the dropdown on each task. Search and filter by priority.
- **Real-time:** open the app in two tabs or devices; creating, editing or deleting a task updates the other one instantly. The header shows Live or Offline.
- **Responsive:** columns stack on phones and sit side by side on larger screens. Supports dark mode and keyboard navigation.

## Structure

```
taskflow/
├── server.js            Express + Socket.IO server
├── config/db.js         MongoDB connection
├── middleware/auth.js   JWT check for protected routes
├── models/              User.js, Task.js
├── routes/              auth.js, tasks.js
└── public/              index.html, css/style.css, js/app.js
```

## API

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | no | Create account, returns token |
| POST | `/api/auth/login` | no | Log in, returns token |
| GET | `/api/auth/me` | yes | Current user |
| GET | `/api/tasks` | yes | List my tasks |
| POST | `/api/tasks` | yes | Create a task |
| PUT | `/api/tasks/:id` | yes | Update a task |
| DELETE | `/api/tasks/:id` | yes | Delete a task |

Send the token as `Authorization: Bearer <token>`. Socket.IO events sent to the owner's sessions: `task:created`, `task:updated`, `task:deleted`.

## Run locally

1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set:
   - `MONGODB_URI`: a free MongoDB Atlas connection string (or a local MongoDB URL)
   - `JWT_SECRET`: any long random string
4. Run `npm start` and open http://localhost:3000.
5. Create an account, add tasks, then open a second tab to see live updates.

## Deploy on Render (supports WebSockets)

Vercel and Netlify serverless functions do not keep WebSocket connections open, so deploy this app on Render, Railway or Heroku.

1. Push this folder to GitHub (`.env` is ignored).
2. On render.com choose **New → Web Service** and connect the repository.
3. Build command: `npm install`. Start command: `npm start`.
4. Add environment variables `MONGODB_URI` and `JWT_SECRET`.
5. In MongoDB Atlas, allow network access from anywhere (0.0.0.0/0).
6. Deploy and open the Render URL.

## Submission checklist

- [ ] Live URL works (register, log in, create/edit/delete tasks)
- [ ] Real-time update visible across two tabs
- [ ] GitHub repository link
- [ ] This project folder / zip
