require('dotenv').config();
const http = require('http');
const path = require('path');
const express = require('express');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const connectDB = require('./config/db');

if (!process.env.JWT_SECRET) {
  console.error('JWT_SECRET is not set. Copy .env.example to .env and add one.');
  process.exit(1);
}

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.set('io', io);

app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// WebSocket authentication: the client sends its token when connecting.
io.use((socket, next) => {
  try {
    const payload = jwt.verify(socket.handshake.auth.token, process.env.JWT_SECRET);
    socket.userId = payload.id;
    next();
  } catch (err) {
    next(new Error('unauthorized'));
  }
});

// Each user gets a private room, so updates only reach their own sessions.
io.on('connection', (socket) => socket.join(`user:${socket.userId}`));

const PORT = process.env.PORT || 3000;
connectDB().then(() => {
  server.listen(PORT, () => console.log(`TaskFlow running at http://localhost:${PORT}`));
});
